<template>
  <div id="app">
    <counter />
  </div>
</template>

<script>
import Counter from './components/Counter.vue'

export default {
  name: 'app',
  components: { Counter }
}
</script>
