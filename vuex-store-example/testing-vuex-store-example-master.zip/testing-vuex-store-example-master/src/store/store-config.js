import counterModule from './counter-module'

export default {
  modules: {
    counter: counterModule
  }
}
