export default {
  increment (state) {
    state.count++
  }
}
