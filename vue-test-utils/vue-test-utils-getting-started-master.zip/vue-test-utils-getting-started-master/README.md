# Getting started with `vue-test-utils`

## Setup

``` bash
npm install
npm test
```

## Resources

- [vue-test-utils docs](https://vue-test-utils.vuejs.org)
- [vue-test-utils repo](https://github.com/vuejs/vue-test-utils)
