import View404 from './_404'

describe('@views/404', () => {
  it('is a valid view', () => {
    expect(View404).toBeAViewComponent()
  })
})
