/**
 * This function should add up 2 passed in values,
 * obviously it can concat strings as well, but let's
 * say it only accepts numbers for now ;)
 *
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 */
export default function sum(a, b) {
  return a + b;
}
