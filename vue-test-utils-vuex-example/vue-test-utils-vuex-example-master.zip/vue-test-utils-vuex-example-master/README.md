# vue-test-utils-vuex-example

> An example repo demonstrating how to mock Vuex in Vue unit tests

## Build Setup

``` bash
# install dependencies
npm install

# run unit tests
npm run unit
```
