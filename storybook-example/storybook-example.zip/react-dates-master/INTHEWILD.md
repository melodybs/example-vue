Please use [pull requests](https://github.com/airbnb/react-dates/pull/new/master) to add your organization and/or project to this document!

Organizations
----------
 - [Airbnb](https://github.com/airbnb)
 - [Стрелочка](https://strelchka.ru)

Projects
----------
