// eslint-disable-next-line import/no-unresolved
require('./lib/initialize');
