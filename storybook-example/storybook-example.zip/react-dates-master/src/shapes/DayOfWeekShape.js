import PropTypes from 'prop-types';

import { WEEKDAYS } from '../constants';

export default PropTypes.oneOf(WEEKDAYS);
