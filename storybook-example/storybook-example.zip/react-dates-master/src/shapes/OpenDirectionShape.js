import PropTypes from 'prop-types';

import {
  OPEN_DOWN,
  OPEN_UP,
} from '../constants';

export default PropTypes.oneOf([OPEN_DOWN, OPEN_UP]);
