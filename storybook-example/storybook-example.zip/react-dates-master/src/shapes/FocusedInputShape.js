import PropTypes from 'prop-types';

import {
  START_DATE,
  END_DATE,
} from '../constants';

export default PropTypes.oneOf([START_DATE, END_DATE]);
