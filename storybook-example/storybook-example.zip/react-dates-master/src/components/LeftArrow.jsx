import LeftArrow from '../svg/arrow-left.svg';

export default LeftArrow;
