import CalendarIcon from '../svg/calendar.svg';

export default CalendarIcon;
