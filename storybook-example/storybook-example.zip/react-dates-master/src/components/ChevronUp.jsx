import ChevronUp from '../svg/chevron-up.svg';

export default ChevronUp;
