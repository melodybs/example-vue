import RightArrow from '../svg/arrow-right.svg';

export default RightArrow;
