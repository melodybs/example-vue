import CloseButton from '../svg/close.svg';

export default CloseButton;
