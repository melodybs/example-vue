import registerCSSInterfaceWithDefaultTheme from './utils/registerCSSInterfaceWithDefaultTheme';

registerCSSInterfaceWithDefaultTheme();
