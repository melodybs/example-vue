// eslint-disable-next-line import/no-unresolved
module.exports = require('./lib/constants');
