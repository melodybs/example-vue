import sinon from 'sinon-sandbox';

afterEach(() => {
  sinon.restore();
});
