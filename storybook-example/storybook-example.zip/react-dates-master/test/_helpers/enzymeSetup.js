import configure from 'enzyme-adapter-react-helper';

configure({ disableLifecycleMethods: true });
